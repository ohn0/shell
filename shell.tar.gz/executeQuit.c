#include "shell.h"

int executeQuit(){
	//Set quit flag to true.
	quit = 1;
	return 0;
}
