#include <stdio.h>
//This is to test piping.
int main(){
	printf("sending text\n");
	return 0;
}

